# theaviationbee's obfuscator
this is a simple obfuscator I made for school
## How to use
> Use with Java 8 and a working console IDE.
1. Download the zip.
2. Extract the zip.
3. Put `build.gradle` into the working directory
4. Put `BuildSystemShort.java` and `Main.java` into your Java root folder (the folder where you run Java)
5. Put the files you want to obfuscate into a separate folder. This is called the "target folder".
6. Run `Main.java`.
7. If you need to, press the generate mappings button and put the mappings file into the target folder.
8. Follow GUI instructions.
9. Pay attention to the console; the files that are generated will be mixed in with the source files.